package com.mobradar;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import com.mojang.brigadier.context.CommandContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class MobRadarMod implements ModInitializer {

    public static final String MOD_ID = "mobradar";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Mob Radar загружен! Используй /radar чтобы найти мобов.");

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                CommandManager.literal("radar")
                    .executes(this::executeRadar)
                    .then(CommandManager.argument("radius",
                            com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 200))
                        .executes(ctx -> executeRadarWithRadius(ctx,
                            com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "radius")))
                    )
            );
        });
    }

    private int executeRadar(CommandContext<ServerCommandSource> context) {
        return executeRadarWithRadius(context, 50);
    }

    private int executeRadarWithRadius(CommandContext<ServerCommandSource> context, int radius) {
        ServerCommandSource source = context.getSource();
        ServerPlayerEntity player = source.getPlayer();

        if (player == null) {
            source.sendError(Text.literal("Эта команда только для игроков!"));
            return 0;
        }

        Box searchBox = player.getBoundingBox().expand(radius);
        List<HostileEntity> mobs = player.getWorld().getEntitiesByClass(
            HostileEntity.class, searchBox, e -> !e.isDead()
        );

        if (mobs.isEmpty()) {
            source.sendFeedback(() -> Text.literal(
                "§a✔ Радар (радиус " + radius + " бл.): враждебных мобов нет. Спокойно!"
            ), false);
            return 1;
        }

        mobs.sort((a, b) -> Double.compare(
            a.squaredDistanceTo(player),
            b.squaredDistanceTo(player)
        ));

        final int total = mobs.size();
        final int r = radius;
        source.sendFeedback(() -> Text.literal(
            "§c☠ РАДАР §7(радиус " + r + " бл.) §c— найдено: " + total
        ), false);

        int show = Math.min(5, mobs.size());
        for (int i = 0; i < show; i++) {
            HostileEntity mob = mobs.get(i);
            double dist = Math.sqrt(mob.squaredDistanceTo(player));
            double dx = mob.getX() - player.getX();
            double dz = mob.getZ() - player.getZ();
            double dy = mob.getY() - player.getY();
            String dir = getDirection(dx, dz);
            String vert = dy > 3 ? " §e↑" + (int)dy + "бл" : dy < -3 ? " §e↓" + (int)Math.abs(dy) + "бл" : "";
            String name = mob.getType().getName().getString();
            String hp = String.format("%.0f", mob.getHealth());

            final String line = "§e" + (i + 1) + ". §f" + name +
                " §7| §c" + String.format("%.1f", dist) + " бл §7| §b" + dir + vert +
                " §7| §d❤ " + hp;
            source.sendFeedback(() -> Text.literal(line), false);
        }

        if (mobs.size() > 5) {
            final int left = mobs.size() - 5;
            source.sendFeedback(() -> Text.literal("§7...и ещё " + left + " мобов за пределами списка"), false);
        }

        source.sendFeedback(() -> Text.literal(
            "§7Подсказка: §f/radar 100 §7— увеличить радиус"
        ), false);

        return 1;
    }

    private String getDirection(double dx, double dz) {
        double angle = Math.toDegrees(Math.atan2(dz, dx));
        if (angle < 0) angle += 360;
        if (angle < 22.5 || angle >= 337.5) return "→ Восток";
        if (angle < 67.5)  return "↘ Юго-Восток";
        if (angle < 112.5) return "↓ Юг";
        if (angle < 157.5) return "↙ Юго-Запад";
        if (angle < 202.5) return "← Запад";
        if (angle < 247.5) return "↖ Северо-Запад";
        if (angle < 292.5) return "↑ Север";
        return "↗ Северо-Восток";
    }
}
